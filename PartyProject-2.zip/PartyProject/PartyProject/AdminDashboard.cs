﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;

namespace PartyProject
{
    public class AdminDashboard
    {
        public static int extension;
        static int numOfGuests;
        static int cakeWeightInKG;
        static int i, m, c, g;
        static int decor, food;
        static string[] guestname = new string[20];
        static string[] mobilenum = new string[20];
        static string dir = Directory.GetCurrentDirectory();
        string[] decorchoices = new string[10];
        string[] vfoodchoices = new string[50];
        string[] nvfoodchoices = new string[50];
        string detailfilename;
        static string userNameForFile;
        public AdminDashboard(string userName)
        {
            userNameForFile = userName;
        }
        public void AdminDashboardSelect()
        {
            HomePage homePageObject = new HomePage();
            Console.BackgroundColor = ConsoleColor.DarkYellow;
            Console.Clear();
            Admin adminObject2 = new Admin();
            HomePage homePageObject3 = new HomePage();
            string userKeyPress;
            int adminDashboardSelection;
        Admin: homePageObject.centerText("Enter your choice");
            homePageObject.centerText("1. Create new Event");
            homePageObject.centerText("2. Display Events");
            homePageObject.centerText("3. Edit existing Events");
            homePageObject.centerText("4. Logout and Go Back");
            homePageObject.centerText("5. Logout and go to Home Page");
            Console.CursorLeft = Console.WindowWidth / 2;
            try
            {
                adminDashboardSelection = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception e)
            {
                homePageObject.centerText("Wrong Format...");
                goto Admin;

            }
            Console.Clear();
            switch (adminDashboardSelection)
            {
                case 1:
                    CreateEvent();
                    homePageObject.centerText("Press e to go back");
                    Console.CursorLeft = Console.WindowWidth / 2;
                    userKeyPress = Console.ReadLine();
                    if (userKeyPress == "e")
                    {
                        Console.Clear();
                        AdminDashboardSelect();
                    }
                    break;
                case 2:
                    DisplayEvents();
                    homePageObject.centerText("Press e to go back");
                    Console.CursorLeft = Console.WindowWidth / 2;
                    userKeyPress = Console.ReadLine();
                    if (userKeyPress == "e")
                    {
                        Console.Clear();
                        AdminDashboardSelect();
                    }
                    break;
                case 3:
                    EditEvents();
                    homePageObject.centerText("Press e to go back");
                    Console.CursorLeft = Console.WindowWidth / 2;
                    userKeyPress = Console.ReadLine();
                    if (userKeyPress == "e")
                    {
                        Console.Clear();
                        AdminDashboardSelect();
                    }
                    break;
                case 4:
                    Console.Clear();
                    adminObject2.AdminSelect();
                    break;
                case 5:
                    Console.Clear();
                    homePageObject3.DisplayHomePage();
                    break;
                default:
                    break;
            }
        }

        public void DisplayEvents()
        {
            HomePage homePageObject = new HomePage();
            int display;
        Event: homePageObject.centerText("Do you want to display");
            homePageObject.centerText("1.Individual Billing");
            homePageObject.centerText("2.Per Event Total Billing");
            homePageObject.centerText("3.All Events Total Billing");
            homePageObject.centerText("4.Go back");
            Console.CursorLeft = Console.WindowWidth / 2;
            try
            {
                display = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception e)
            {
                homePageObject.centerText("\n Wrong Format...");
                goto Event;

            }
            switch (display)
            {
                case 1:
                    Console.Clear();
                    homePageObject.centerText("************ Individual Bill ************");
                    GenIndividualBill();
                    break;
                case 2:
                    Console.Clear();
                    homePageObject.centerText("************ Event Total Bill ************");
                    EventIndividualBill();
                    break;
                case 3:
                    Console.Clear();
                    homePageObject.centerText("************ Total Bill ************");
                    GenerateBill();
                    break;
                case 4:
                    AdminDashboardSelect();
                    break;
                default:
                    break;
            }
        }

        //Getting bill for a single person
        public void GenIndividualBill()
        {

            HomePage homePageObject = new HomePage();
            string dir = Directory.GetCurrentDirectory();
            string userFileName2 = dir + userNameForFile + ".txt";
            if (!File.Exists(userFileName2))
            {
                homePageObject.centerText("You have not created any event");
                homePageObject.centerText("Press any key to go back");
                Console.ReadKey();
                AdminDashboardSelect();
            }

            string[] filearray2 = File.ReadAllLines(userFileName2);
            


            EventChoiceSection: homePageObject.centerText("Choose the event to display the bill");
            int eventNumber = 1;
            foreach(string eid in filearray2)
            {
                string basicDetailsFilename = dir + "BasicDetails" + eid + ".txt";
                string[] basicDetailsFilearray = File.ReadAllLines(basicDetailsFilename);
                homePageObject.centerText($"{eventNumber}. Event {basicDetailsFilearray[0]}");
                homePageObject.centerText($"Event type is {basicDetailsFilearray[1]}, on {basicDetailsFilearray[2]} with {basicDetailsFilearray[3]} number of guests");
                homePageObject.centerText($"Event ID is {basicDetailsFilearray[4]}");
                eventNumber++;
            }
            int enteredEventChoice;
            Console.CursorLeft = Console.WindowWidth / 2;
            try
            {
                enteredEventChoice = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception e)
            {
                homePageObject.centerText("Wrong Format...");
                goto EventChoiceSection;

            }
            if(enteredEventChoice>filearray2.Length)
            {
                homePageObject.centerText("Wrong choice, please enter a valid choice");
                goto EventChoiceSection;
            }
            int ext = Convert.ToInt32(filearray2[enteredEventChoice - 1]);

            int i1 = 1;

            int perIndividualTotal = 0;
            i1 = 1;
            homePageObject.centerText($" -------Bill Details of Event {enteredEventChoice}------- :");
            string fname = dir + "Details" + ext + ".txt";
            string[] filearray = File.ReadAllLines(fname);

            int z = 0;
            int flag = 2;
            foreach (var item in filearray)
            {
                //**** is for Individual specific items(food, games, return gifts)
                if (item == "****")
                {
                    flag = 3;

                    z = 0;
                    continue;
                }
                //***** is for general items(decor types, cake, music)
                if (item == "*****")
                {
                    flag = 2;
                    continue;
                }
                if (flag == 2)
                {
                    z++;
                }
                else
                {
                    if (z % 3 == 0)
                    {
                        homePageObject.centerText($"{item} ");
                        z++;
                    }
                    else if (z % 3 == 1)
                    {
                        z++;
                    }
                    else
                    {
                        homePageObject.centerText($"Per person price is : {item}");
                        perIndividualTotal = perIndividualTotal + Convert.ToInt32(item);
                        z++;
                    }
                }

            }
            homePageObject.centerText($"Total for One Person is { perIndividualTotal}");
            i1++;



        }


        public void EventIndividualBill()
        {

            HomePage homePageObject = new HomePage();
            string dir = Directory.GetCurrentDirectory();
            string userFileName2 = dir + userNameForFile + ".txt";
            if (!File.Exists(userFileName2))
            {
                homePageObject.centerText("You have not created any event");
                homePageObject.centerText("Press any key to go back");
                Console.ReadKey();
                AdminDashboardSelect();
            }
            string[] filearray3 = File.ReadAllLines(userFileName2);

            homePageObject.centerText("Choose the event to display the bill");
            int eventNumber = 1;
            foreach (string eid in filearray3)
            {
                string basicDetailsFilename = dir + "BasicDetails" + eid + ".txt";
                string[] basicDetailsFilearray = File.ReadAllLines(basicDetailsFilename);
                homePageObject.centerText($"{eventNumber}. Event {basicDetailsFilearray[0]}");
                homePageObject.centerText($"Event type is {basicDetailsFilearray[1]}, on {basicDetailsFilearray[2]} with {basicDetailsFilearray[3]} number of guests");
                homePageObject.centerText($"Event ID is {basicDetailsFilearray[4]}");
                eventNumber++;
            }
            Console.CursorLeft = Console.WindowWidth / 2;
            int enteredEventChoice = Convert.ToInt32(Console.ReadLine());
            int ext = Convert.ToInt32(filearray3[enteredEventChoice - 1]);
            int eventNum = ext;

        BillChoiceSection: homePageObject.centerText("Do you want to see");
            homePageObject.centerText("1. Estimated Final Bill");
            homePageObject.centerText("2. Current Bill");
            Console.CursorLeft = Console.WindowWidth / 2;
            int billChoice = Convert.ToInt32(Console.ReadLine());
            switch (billChoice)
            {
                case 1:

                    int total = 0;
                    int perEventTotal = 0;
                    perEventTotal = 0;
                    int i1 = 1;
                    homePageObject.centerText($"-------Bill Details of Event {enteredEventChoice}------- :");
                    Console.WriteLine("\n");
                    var arr = new[]
                    {
                          @"         --------------------------------------------------------------       ",
                          @"         |                 Item                 |        Price        |       ",
                          @"         --------------------------------------------------------------       ",

                    };
                    foreach(var line in arr)
                    {
                        homePageObject.centerText(line);
                    }
                    string fname = dir + "Details" + ext + ".txt";
                    string[] filearray = File.ReadAllLines(fname);

                    int z = 0;
                    int flag = 2;
                    foreach (var item in filearray)
                    {
                        //**** is for Individual specific items(food, games, return gifts)
                        if (item == "****")
                        {
                            flag = 3;
                            z = 0;
                            continue;
                        }
                        //***** is for general items(decor types, cake, music)
                        if (item == "*****")
                        {
                            flag = 2;
                            continue;
                        }
                        if (flag == 2)
                        {
                            if (z % 2 == 0)
                            {
                                //Console.Write($"\n {item} price : ");
                                
                                Console.CursorLeft = (Console.WindowWidth / 2)-31;
                                Console.Write("|");
                                for (int i = 0; i < (38 - item.Length) / 2; i++)
                                    Console.Write(" ");
                                
                                Console.Write($"{item}");
                                if((38 - item.Length)%2==0)
                                {
                                    for (int i = 0; i < (38 - item.Length) / 2; i++)
                                        Console.Write(" ");
                                }
                                else
                                {
                                    for (int i = 0; i < ((38 - item.Length) / 2)+1; i++)
                                        Console.Write(" ");
                                }
                                
                                z++;
                            }
                            else
                            {
                                Console.Write("|");
                                for (int i = 0; i < (21 - item.Length) / 2; i++)
                                    Console.Write(" ");
                                Console.Write($"{item}");
                                if ((21 - item.Length) % 2 == 0)
                                {
                                    for (int i = 0; i < (21 - item.Length) / 2; i++)
                                        Console.Write(" ");
                                }
                                else
                                {
                                    for (int i = 0; i < ((21 - item.Length) / 2) + 1; i++)
                                        Console.Write(" ");
                                }
                                Console.WriteLine("|");
                                //Console.WriteLine(item);
                                total = total + Convert.ToInt32(item);
                                perEventTotal = perEventTotal + Convert.ToInt32(item);
                                z++;
                            }
                        }
                        else
                        {
                            if (z % 3 == 0)
                            {
                                //Console.Write($"\n  {item} price : ");
                                Console.CursorLeft = (Console.WindowWidth / 2) - 31;
                                Console.Write("|");
                                for (int i = 0; i < (38 - item.Length) / 2; i++)
                                    Console.Write(" ");
                                Console.Write($"{item}");
                                if ((38 - item.Length) % 2 == 0)
                                {
                                    for (int i = 0; i < (38 - item.Length) / 2; i++)
                                        Console.Write(" ");
                                }
                                else
                                {
                                    for (int i = 0; i < ((38 - item.Length) / 2) + 1; i++)
                                        Console.Write(" ");
                                }
                                z++;
                            }
                            else if (z % 3 == 1)
                            {
                                //Console.WriteLine(item);
                                total = total + Convert.ToInt32(item);
                                Console.Write("|");
                                for (int i = 0; i < (21 - item.Length) / 2; i++)
                                    Console.Write(" ");
                                Console.Write($"{item}");
                                if ((21 - item.Length) % 2 == 0)
                                {
                                    for (int i = 0; i < (21 - item.Length) / 2; i++)
                                        Console.Write(" ");
                                }
                                else
                                {
                                    for (int i = 0; i < ((21 - item.Length) / 2) + 1; i++)
                                        Console.Write(" ");
                                }
                                Console.WriteLine("|");
                                perEventTotal = perEventTotal + Convert.ToInt32(item);
                                z++;
                            }
                            else
                            {
                                //Console.WriteLine($"Per person price is : {item}");
                                z++;
                            }
                        }

                    }
                    homePageObject.centerText("--------------------------------------------------------------");
                    homePageObject.centerText($"Total for Event {enteredEventChoice} is {perEventTotal}");
                    i1++;

                    break;
                case 2:

                    int total2 = 0;
                    int perEventTotal2 = 0;
                    perEventTotal2 = 0;
                    int i2 = 1;
                    string guestAttendedFilename = dir + "GuestsAttended" + ext + ".txt";
                    string[] attendedfilearray;
                    try
                    {
                         attendedfilearray = File.ReadAllLines(guestAttendedFilename);
                    }
                    catch (Exception e)
                    {
                        homePageObject.centerText($"No guest has attended Event {enteredEventChoice} yet, please refer to estimated bill");
                        goto BillChoiceSection;
                    }
                    homePageObject.centerText($"-------Bill Details of Event  {enteredEventChoice} ------- :");
                    Console.WriteLine("\n");
                    var arr2 = new[]
                    {
                          @"         --------------------------------------------------------------       ",
                          @"         |                 Item                 |        Price        |       ",
                          @"         --------------------------------------------------------------       ",

                    };
                    foreach (var line in arr2)
                    {
                        homePageObject.centerText(line);
                    }

                    string fname2 = dir + "Details" + ext + ".txt";
                    string[] filearray2 = File.ReadAllLines(fname2);

                    int z2 = 0;
                    int flag2 = 2;
                    foreach (var item in filearray2)
                    {
                        //**** is for Individual specific items(food, games, return gifts)
                        if (item == "****")
                        {
                            flag2 = 3;
                            z2 = 0;
                            continue;
                        }
                        //***** is for general items(decor types, cake, music)
                        if (item == "*****")
                        {
                            flag2 = 2;
                            continue;
                        }
                        if (flag2 == 2)
                        {
                            if (z2 % 2 == 0)
                            {
                                //Console.Write($"\n  {item} price : ");
                                Console.CursorLeft = (Console.WindowWidth / 2) - 31;
                                Console.Write("|");
                                for (int i = 0; i < (38 - item.Length) / 2; i++)
                                    Console.Write(" ");

                                Console.Write($"{item}");
                                if ((38 - item.Length) % 2 == 0)
                                {
                                    for (int i = 0; i < (38 - item.Length) / 2; i++)
                                        Console.Write(" ");
                                }
                                else
                                {
                                    for (int i = 0; i < ((38 - item.Length) / 2) + 1; i++)
                                        Console.Write(" ");
                                }
                                z2++;
                            }
                            else
                            {
                                Console.Write("|");
                                for (int i = 0; i < (21 - item.Length) / 2; i++)
                                    Console.Write(" ");
                                Console.Write($"{item}");
                                if ((21 - item.Length) % 2 == 0)
                                {
                                    for (int i = 0; i < (21 - item.Length) / 2; i++)
                                        Console.Write(" ");
                                }
                                else
                                {
                                    for (int i = 0; i < ((21 - item.Length) / 2) + 1; i++)
                                        Console.Write(" ");
                                }
                                Console.WriteLine("|");
                                //Console.WriteLine(item);
                                total2 = total2 + Convert.ToInt32(item);
                                perEventTotal2 = perEventTotal2 + Convert.ToInt32(item);
                                z2++;
                            }
                        }
                        else
                        {
                            if (z2 % 3 == 0)
                            {
                                Console.CursorLeft = (Console.WindowWidth / 2) - 31;
                                Console.Write("|");
                                for (int i = 0; i < (38 - item.Length) / 2; i++)
                                    Console.Write(" ");
                                Console.Write($"{item}");
                                if ((38 - item.Length) % 2 == 0)
                                {
                                    for (int i = 0; i < (38 - item.Length) / 2; i++)
                                        Console.Write(" ");
                                }
                                else
                                {
                                    for (int i = 0; i < ((38 - item.Length) / 2) + 1; i++)
                                        Console.Write(" ");
                                }
                                z2++;
                            }
                            else if (z2 % 3 == 1)
                            {

                                z2++;
                            }
                            else
                            {
                                Console.Write("|");
                                for (int i = 0; i < (21 - Convert.ToString(Convert.ToInt32(item) * attendedfilearray.Length).Length) / 2; i++)
                                    Console.Write(" ");
                                Console.Write($"{Convert.ToInt32(item) * attendedfilearray.Length}");
                                if ((21 - Convert.ToString(Convert.ToInt32(item) * attendedfilearray.Length).Length) % 2 == 0)
                                {
                                    for (int i = 0; i < (21 - Convert.ToString(Convert.ToInt32(item) * attendedfilearray.Length).Length) / 2; i++)
                                        Console.Write(" ");
                                }
                                else
                                {
                                    for (int i = 0; i < ((21 - Convert.ToString(Convert.ToInt32(item) * attendedfilearray.Length).Length) / 2) + 1; i++)
                                        Console.Write(" ");
                                }
                                Console.WriteLine("|");

                                //Console.WriteLine(Convert.ToInt32(item) * attendedfilearray.Length);
                                total2 = total2 + (Convert.ToInt32(item) * attendedfilearray.Length);
                                perEventTotal2 = perEventTotal2 + (Convert.ToInt32(item) * attendedfilearray.Length);
                                //Console.WriteLine($"Per person price is : {item}");
                                z2++;
                            }
                        }

                    }
                    homePageObject.centerText("--------------------------------------------------------------");
                    homePageObject.centerText($"Total for Event {enteredEventChoice} is {perEventTotal2}");
                    i2++;

                    break;
                default:
                    Console.WriteLine("\n Wrong choice");
                    break;
            }




        }
        //For generating total bill of all events created by single planner
        public void GenerateBill()
        {
            HomePage homePageObject = new HomePage();
            string dir = Directory.GetCurrentDirectory();
            string userFileName2 = dir + userNameForFile + ".txt";
            if (!File.Exists(userFileName2))
            {
                homePageObject.centerText("You have not created any event");
                homePageObject.centerText("Press any key to go back");
                Console.ReadKey();
                AdminDashboardSelect();
            }
            string[] filearray2 = File.ReadAllLines(userFileName2);
        GenBill: homePageObject.centerText("Do you want to see");
            homePageObject.centerText("1. Estimated Final Bill");
            homePageObject.centerText("2. Current Bill");
            Console.CursorLeft = Console.WindowWidth / 2;
            int billChoice = Convert.ToInt32(Console.ReadLine());
            switch (billChoice)
            {
                case 1:

                    int total = 0;
                    int perEventTotal = 0;

                    int i1 = 1;
                    foreach (var ext in filearray2)
                    {
                        perEventTotal = 0;
                        homePageObject.centerText($"-------Bill Details of Event {i1}------- :");
                        Console.WriteLine("\n");
                        var arr = new[]
                        {
                          @"         --------------------------------------------------------------       ",
                          @"         |                 Item                 |        Price        |       ",
                          @"         --------------------------------------------------------------       ",

                        };
                        foreach (var line in arr)
                        {
                            homePageObject.centerText(line);
                        }
                        string fname = dir + "Details" + ext + ".txt";
                        string[] filearray = File.ReadAllLines(fname);

                        int z = 0;
                        int flag = 2;
                        foreach (var item in filearray)
                        {
                            //**** is for Individual specific items(food, games, return gifts)
                            if (item == "****")
                            {
                                flag = 3;
                                z = 0;
                                continue;
                            }
                            //***** is for general items(decor types, cake, music)
                            if (item == "*****")
                            {
                                flag = 2;
                                continue;
                            }
                            if (flag == 2)
                            {
                                if (z % 2 == 0)
                                {
                                    Console.CursorLeft = (Console.WindowWidth / 2) - 31;
                                    Console.Write("|");
                                    for (int i = 0; i < (38 - item.Length) / 2; i++)
                                        Console.Write(" ");

                                    Console.Write($"{item}");
                                    if ((38 - item.Length) % 2 == 0)
                                    {
                                        for (int i = 0; i < (38 - item.Length) / 2; i++)
                                            Console.Write(" ");
                                    }
                                    else
                                    {
                                        for (int i = 0; i < ((38 - item.Length) / 2) + 1; i++)
                                            Console.Write(" ");
                                    }
                                    z++;
                                }
                                else
                                {
                                    Console.Write("|");
                                    for (int i = 0; i < (21 - item.Length) / 2; i++)
                                        Console.Write(" ");
                                    Console.Write($"{item}");
                                    if ((21 - item.Length) % 2 == 0)
                                    {
                                        for (int i = 0; i < (21 - item.Length) / 2; i++)
                                            Console.Write(" ");
                                    }
                                    else
                                    {
                                        for (int i = 0; i < ((21 - item.Length) / 2) + 1; i++)
                                            Console.Write(" ");
                                    }
                                    Console.WriteLine("|");
                                    total = total + Convert.ToInt32(item);
                                    perEventTotal = perEventTotal + Convert.ToInt32(item);
                                    z++;
                                }
                            }
                            else
                            {
                                if (z % 3 == 0)
                                {
                                    Console.CursorLeft = (Console.WindowWidth / 2) - 31;
                                    Console.Write("|");
                                    for (int i = 0; i < (38 - item.Length) / 2; i++)
                                        Console.Write(" ");
                                    Console.Write($"{item}");
                                    if ((38 - item.Length) % 2 == 0)
                                    {
                                        for (int i = 0; i < (38 - item.Length) / 2; i++)
                                            Console.Write(" ");
                                    }
                                    else
                                    {
                                        for (int i = 0; i < ((38 - item.Length) / 2) + 1; i++)
                                            Console.Write(" ");
                                    }
                                    z++;
                                }
                                else if (z % 3 == 1)
                                {
                                    Console.Write("|");
                                    for (int i = 0; i < (21 - item.Length) / 2; i++)
                                        Console.Write(" ");
                                    Console.Write($"{item}");
                                    if ((21 - item.Length) % 2 == 0)
                                    {
                                        for (int i = 0; i < (21 - item.Length) / 2; i++)
                                            Console.Write(" ");
                                    }
                                    else
                                    {
                                        for (int i = 0; i < ((21 - item.Length) / 2) + 1; i++)
                                            Console.Write(" ");
                                    }
                                    Console.WriteLine("|");
                                    total = total + Convert.ToInt32(item);
                                    perEventTotal = perEventTotal + Convert.ToInt32(item);
                                    z++;
                                }
                                else
                                {
                                    //Console.WriteLine($"Per person price is : {item}");
                                    z++;
                                }
                            }

                        }
                        homePageObject.centerText("--------------------------------------------------------------");
                        homePageObject.centerText($"Total for Event {i1} is {perEventTotal}");
                        Console.WriteLine();
                        i1++;
                    }
                    Console.WriteLine("");

                    homePageObject.centerText($"Total amount for all events is {total}");

                    break;
                case 2:

                    int total2 = 0;
                    int perEventTotal2 = 0;

                    int i2 = 1;
                    foreach (var ext in filearray2)
                    {
                        string guestAttendedFilename = dir + "GuestsAttended" + ext + ".txt";
                        string[] attendedfilearray;
                        try
                        {
                            attendedfilearray = File.ReadAllLines(guestAttendedFilename);
                        }
                        catch (Exception e)
                        {
                            homePageObject.centerText($"No guest has attended Event {i2} yet, please refer to estimated bill");
                            i2++;
                            continue;
                        }

                        perEventTotal2 = 0;
                        homePageObject.centerText($"-------Bill Details of Event {i2}------- :");
                        Console.WriteLine("\n");
                        var arr = new[]
                        {
                          @"         --------------------------------------------------------------       ",
                          @"         |                 Item                 |        Price        |       ",
                          @"         --------------------------------------------------------------       ",

                        };
                        foreach (var line in arr)
                        {
                            homePageObject.centerText(line);
                        }
                        string fname = dir + "Details" + ext + ".txt";
                        string[] filearray = File.ReadAllLines(fname);

                        int z = 0;
                        int flag = 2;
                        foreach (var item in filearray)
                        {
                            //**** is for Individual specific items(food, games, return gifts)
                            if (item == "****")
                            {
                                flag = 3;
                                z = 0;
                                continue;
                            }
                            //***** is for general items(decor types, cake, music)
                            if (item == "*****")
                            {
                                flag = 2;
                                continue;
                            }
                            if (flag == 2)
                            {
                                if (z % 2 == 0)
                                {
                                    Console.CursorLeft = (Console.WindowWidth / 2) - 31;
                                    Console.Write("|");
                                    for (int i = 0; i < (38 - item.Length) / 2; i++)
                                        Console.Write(" ");

                                    Console.Write($"{item}");
                                    if ((38 - item.Length) % 2 == 0)
                                    {
                                        for (int i = 0; i < (38 - item.Length) / 2; i++)
                                            Console.Write(" ");
                                    }
                                    else
                                    {
                                        for (int i = 0; i < ((38 - item.Length) / 2) + 1; i++)
                                            Console.Write(" ");
                                    }
                                    z++;
                                }
                                else
                                {
                                    Console.Write("|");
                                    for (int i = 0; i < (21 - item.Length) / 2; i++)
                                        Console.Write(" ");
                                    Console.Write($"{item}");
                                    if ((21 - item.Length) % 2 == 0)
                                    {
                                        for (int i = 0; i < (21 - item.Length) / 2; i++)
                                            Console.Write(" ");
                                    }
                                    else
                                    {
                                        for (int i = 0; i < ((21 - item.Length) / 2) + 1; i++)
                                            Console.Write(" ");
                                    }
                                    Console.WriteLine("|");
                                    total2 = total2 + Convert.ToInt32(item);
                                    perEventTotal2 = perEventTotal2 + Convert.ToInt32(item);
                                    z++;
                                }
                            }
                            else
                            {
                                if (z % 3 == 0)
                                {
                                    Console.CursorLeft = (Console.WindowWidth / 2) - 31;
                                    Console.Write("|");
                                    for (int i = 0; i < (38 - item.Length) / 2; i++)
                                        Console.Write(" ");
                                    Console.Write($"{item}");
                                    if ((38 - item.Length) % 2 == 0)
                                    {
                                        for (int i = 0; i < (38 - item.Length) / 2; i++)
                                            Console.Write(" ");
                                    }
                                    else
                                    {
                                        for (int i = 0; i < ((38 - item.Length) / 2) + 1; i++)
                                            Console.Write(" ");
                                    }
                                    z++;
                                }
                                else if (z % 3 == 1)
                                {

                                    z++;
                                }
                                else
                                {
                                    Console.Write("|");
                                    for (int i = 0; i < (21 - Convert.ToString(Convert.ToInt32(item) * attendedfilearray.Length).Length) / 2; i++)
                                        Console.Write(" ");
                                    Console.Write($"{Convert.ToInt32(item) * attendedfilearray.Length}");
                                    if ((21 - Convert.ToString(Convert.ToInt32(item) * attendedfilearray.Length).Length) % 2 == 0)
                                    {
                                        for (int i = 0; i < (21 - Convert.ToString(Convert.ToInt32(item) * attendedfilearray.Length).Length) / 2; i++)
                                            Console.Write(" ");
                                    }
                                    else
                                    {
                                        for (int i = 0; i < ((21 - Convert.ToString(Convert.ToInt32(item) * attendedfilearray.Length).Length) / 2) + 1; i++)
                                            Console.Write(" ");
                                    }
                                    Console.WriteLine("|");

                                    //Console.WriteLine(Convert.ToInt32(item) * attendedfilearray.Length);
                                    total2 = total2 + (Convert.ToInt32(item) * attendedfilearray.Length);
                                    perEventTotal2 = perEventTotal2 + (Convert.ToInt32(item) * attendedfilearray.Length);
                                    z++;
                                }
                            }

                        }

                        homePageObject.centerText("--------------------------------------------------------------");
                        homePageObject.centerText($"Total for Event {i2} is {perEventTotal2}");
                        Console.WriteLine();
                        i2++;
                    }
                    Console.WriteLine();
                    homePageObject.centerText($"Total amount is {total2}");

                    break;
                default:
                    homePageObject.centerText("Wrong choice");
                    break;
            }



        }

        public void EditEvents()
        {

            HomePage homePageObject = new HomePage();
            homePageObject.centerText("Edit Events");
            Console.WriteLine("\n");
            string dir = Directory.GetCurrentDirectory();


            string userFileName2 = dir + userNameForFile + ".txt";
            if (!File.Exists(userFileName2))
            {
                homePageObject.centerText("You have not created any event");
                homePageObject.centerText("Press any key to go back");
                Console.ReadKey();
                AdminDashboardSelect();
            }
            string[] filearray2 = File.ReadAllLines(userFileName2);

        EventChoiceSection: homePageObject.centerText("Choose the event to be edited");
            int eventNumber = 1;
            foreach (string eid in filearray2)
            {
                string basicDetailsFilename = dir + "BasicDetails" + eid + ".txt";
                string[] basicDetailsFilearray = File.ReadAllLines(basicDetailsFilename);
                homePageObject.centerText($"{eventNumber}. Event {basicDetailsFilearray[0]}");
                homePageObject.centerText($"Event type is {basicDetailsFilearray[1]}, on {basicDetailsFilearray[2]} with {basicDetailsFilearray[3]} number of guests");
                homePageObject.centerText($"Event ID is {basicDetailsFilearray[4]}");
                eventNumber++;
            }
            int enteredEventChoice;
            Console.CursorLeft = Console.WindowWidth / 2;
            try
            {
                enteredEventChoice = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception e)
            {
                homePageObject.centerText("Wrong Format...");
                goto EventChoiceSection;

            }
            if (enteredEventChoice > filearray2.Length)
            {
                homePageObject.centerText("Wrong choice, please enter a valid choice");
                goto EventChoiceSection;
            }
            int ext = Convert.ToInt32(filearray2[enteredEventChoice - 1]);


            string fname = dir + "GuestCredentials" + ext + ".txt";
            string[] filearray = File.ReadAllLines(fname);
            int i1 = 0, i2 = 0;

            //Displaying all existing username and passwords for particular event
            foreach (var item in filearray)
            {
                if (i1 % 2 == 0)
                {
                    homePageObject.centerText($"Username of Guest {i2 + 1} is {item}");
                }
                else
                {
                    homePageObject.centerText($"Password of Guest {i2 + 1} is {item}");
                    i2++;
                }
                i1++;
            }

            //Asking planner which guest details to edit
            while (true)
            {
                int guestNumber;
            Guestnum: homePageObject.centerText("Enter the Guest number you want to edit or press 99 to go back");
                Console.CursorLeft = Console.WindowWidth / 2;
                try
                {
                    guestNumber = Convert.ToInt32(Console.ReadLine());

                }
                catch (Exception e)
                {
                    homePageObject.centerText("Wrong Format...");
                    goto Guestnum;

                }

                if (guestNumber == 99)
                {
                    break;
                }
                i2 = 1;
                int temp;
                string temp2;
                for (int i3 = 0; i3 < filearray.Length; i3++)
                {

                    if (i2 == guestNumber)
                    {
                    UPChoice: homePageObject.centerText("Enter which you want to change");
                        homePageObject.centerText("1. Username");
                        homePageObject.centerText("2. Password");
                        Console.CursorLeft = Console.WindowWidth / 2;
                        try
                        {
                            temp = Convert.ToInt32(Console.ReadLine());

                        }
                        catch (Exception e)
                        {
                            homePageObject.centerText("Wrong Format...");
                            goto UPChoice;

                        }
                        switch (temp)
                        {
                            case 1:
                                homePageObject.centerText($"Enter the new username for Guest {i2} instead of {filearray[i3]}");
                                Console.CursorLeft = Console.WindowWidth / 2;
                                temp2 = Console.ReadLine();
                                filearray[i3] = temp2;
                                i3 = filearray.Length;
                                break;
                            case 2:
                                homePageObject.centerText($"Enter the new password for Guest {i2} instead of {filearray[i3 + 1]}");
                                Console.CursorLeft = Console.WindowWidth / 2;
                                temp2 = Console.ReadLine();
                                filearray[i3 + 1] = temp2;
                                i3 = filearray.Length;
                                break;

                            default:
                                break;
                        }

                    }
                    if (i3 % 2 == 1)
                    {
                        i2++;
                    }
                }
            }

            //Rewriting the file with all the changes
            using (StreamWriter wrt = File.CreateText(fname))
            {
                foreach (var it in filearray)
                {
                    wrt.WriteLine(it);
                }
            }
            AdminDashboardSelect();
        }

        public void CreateEvent()
        {

            HomePage homePageObject = new HomePage();
            extension = 1;
            homePageObject.centerText("Please enter a name for your event");
            Console.CursorLeft = (Console.WindowWidth / 2)-6;
            string enteredEventName = Console.ReadLine();
            string[] eventname = { "Birthday", "Marriage", "Get-to-gether", "Corporate" };
        eventChoiceSection: homePageObject.centerText("Enter the Event you are planning for");
            for (int i = 0; i < eventname.Length; i++)
            {
                homePageObject.centerText($"{i + 1}. {eventname[i]}");
            }
            string eventType;
            int eventChoice;
            Console.CursorLeft = Console.WindowWidth / 2;
            try
            {
                eventChoice = Convert.ToInt32(Console.ReadLine());

            }
            catch (Exception e)
            {
                homePageObject.centerText("Wrong Format...");
                goto eventChoiceSection;

            }

            eventType = eventname[eventChoice - 1];
            if (eventChoice > eventname.Length || eventChoice < 1)
            {
                homePageObject.centerText("Wrong choice, please choose again");
                goto eventChoiceSection;
            }

        //Getting event date from user
        dateSection: homePageObject.centerText("Enter which Date you want for Event: ");
            DateTime dt = new DateTime();
            DateTime date = DateTime.Now;
            TimeSpan ts = new TimeSpan(0, 0, 0);
            date = date.Date + ts;
            Console.CursorLeft = (Console.WindowWidth / 2)-5;
            try
            {

                dt = Convert.ToDateTime(Console.ReadLine());
            }
            catch (Exception e)
            {
                homePageObject.centerText("Wrong date format");
                goto dateSection;

            }

            //Checking if entered date is before or equal to current date
            if (!(dt >= date))
            {
                homePageObject.centerText($"current date is {date} and entered date is {dt} expression is {!(dt >= date)}");

                homePageObject.centerText("Cannot book date for Event");
                goto dateSection;
            }

        //Asking for number of guest
        num: homePageObject.centerText("Enter the number of Guests You are Inviting for the Event: ");
            Console.CursorLeft = Console.WindowWidth / 2;
            try
            {
                numOfGuests = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception e)
            {
                homePageObject.centerText("Wrong format");
                goto num;
            }
            if (numOfGuests > 20)
            {
                homePageObject.centerText("Maximum capacity exceeded, please give guest number below 20");
            }

            //Getting guest details from planner
            for (int i = 0; i < numOfGuests; i++)
            {
                homePageObject.centerText($"Enter name of guest {i + 1}");
                Console.CursorLeft = Console.WindowWidth / 2;
                guestname[i] = Console.ReadLine();
                homePageObject.centerText($"Enter the mobile number(password) of {guestname[i]}: ");
                Console.CursorLeft = Console.WindowWidth / 2;
                mobilenum[i] = Console.ReadLine();
            }

            //Asking if cake is required
            homePageObject.centerText("Do you want cake Y/N?");
            Console.CursorLeft = Console.WindowWidth / 2;
            string cakeChoice = Console.ReadLine();
            if (cakeChoice.ToLower() == "y")
            {
                homePageObject.centerText("How much cake do you want (in kg) ?");
                Console.CursorLeft = Console.WindowWidth / 2;
                cakeWeightInKG = Convert.ToInt32(Console.ReadLine());

            }
            else { }

            //Using Dictionary to store all available decor types
            Dictionary<string, string> decorst = new Dictionary<string, string>();
            Console.Clear();

            //Asking planner to choose multiple desired decor types
            homePageObject.centerText("Choose Your Decor types...");

            decorst.Add("Stage decoration", "5000");
            decorst.Add("Table decoration", "3000");
            decorst.Add("Balloon decoration", "2500");
            decorst.Add("Backdrop decoration", "3500");
            decorst.Add("Flower decoration", "8000");

            int k, l;
            m = 0;
            while (true)
            {

            decorchoiceSection: k = 1;
                foreach (KeyValuePair<string, string> item in decorst)
                {
                    homePageObject.centerText($"Decor type{k} : {item.Key} Cost : {item.Value}");
                    k++;
                }
                homePageObject.centerText("Enter 99 key to exit");

                Console.CursorLeft = Console.WindowWidth / 2;
                try
                {
                    decor = Convert.ToInt32(Console.ReadLine());
                }
                catch (Exception e)
                {
                    homePageObject.centerText("Wrong format");
                    goto decorchoiceSection;
                }

                if (decor == 99)
                {

                    break;
                }
                l = 1;
                foreach (KeyValuePair<string, string> item in decorst)
                {
                    if (decor == l)
                    {
                        //If the planner has already chosen the same decor type earlier
                        if (decorchoices.Contains(Convert.ToString(item.Key)))
                        {
                            homePageObject.centerText("You have already selected this option, please select another option");
                            break;
                        }
                        //Storing the chosen decor type name an total price for all guests in array
                        decorchoices[m] = Convert.ToString(item.Key);
                        decorchoices[m + 1] = Convert.ToString(item.Value);
                        m += 2;
                        break;
                    }
                    l++;
                }
            }

            Console.Clear();
        //Asking user for food preference(veg or non veg)
        foodsection: homePageObject.centerText("Enter your food Preference");
            homePageObject.centerText("1.Veg");
            homePageObject.centerText("2.Non-Veg");
            int foodchoice;
            Console.CursorLeft = Console.WindowWidth / 2;
            try
            {
                foodchoice = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception e)
            {
                homePageObject.centerText("Wrong format");
                goto foodsection;
            }
            switch (foodchoice)
            {
                case 1:
                    homePageObject.centerText("Choose a meal type and select your desired add on desserts...");
                    //Using dictionary to store available Veg food options
                    Dictionary<string, string> vfoodst = new Dictionary<string, string>();
                    vfoodst.Add("Veg Soup", "100");
                    vfoodst.Add("Basic veg breakfast meal", "350");
                    vfoodst.Add("Premium veg breakfast meal", "700");
                    vfoodst.Add("Basic veg platter", "550");
                    vfoodst.Add("Premium veg platter", "1100");
                    vfoodst.Add("Basic veg dinner meal", "400");
                    vfoodst.Add("Premium veg dinner meal", "800");
                    vfoodst.Add("Rasagulla(4pieces)", "150");
                    vfoodst.Add("Kova (50gms)", "100");
                    vfoodst.Add("Gulab Jaamun(4pieces)", "100");
                    vfoodst.Add("Ice Cream", "50");
                    vfoodst.Add("Vegtable/Fruit salad", "100");

                    int a, b;
                    c = 0;
                    //Asking planner to choose multiple desired veg food options
                    while (true)
                    {
                    vegfoodSection:
                        a = 1;
                        foreach (KeyValuePair<string, string> item in vfoodst)
                        {
                            homePageObject.centerText($"Veg Food type{a} : {item.Key} Cost : {item.Value}");
                            a++;
                        }
                        homePageObject.centerText("Enter 99 key to exit");

                        Console.CursorLeft = Console.WindowWidth / 2;
                        try
                        {
                            food = Convert.ToInt32(Console.ReadLine());
                        }
                        catch (Exception excep)
                        {
                            homePageObject.centerText("Wrong format");
                            goto vegfoodSection;
                        }

                        if (food == 99)
                        {

                            break;
                        }
                        b = 1;
                        foreach (KeyValuePair<string, string> item in vfoodst)
                        {
                            if (food == b)
                            {
                                //If user has already selected the same option earlier
                                if (vfoodchoices.Contains(Convert.ToString(item.Key)))
                                {
                                    homePageObject.centerText("You have already selected this option, please select another option");
                                    break;
                                }
                                //Storing the veg food choice name an total price for all guests in array
                                vfoodchoices[c] = Convert.ToString(item.Key);
                                vfoodchoices[c + 1] = Convert.ToString(Convert.ToInt32((item.Value)) * numOfGuests);
                                c += 2;
                                break;
                            }
                            b++;
                        }
                    }
                    break;
                case 2:
                    homePageObject.centerText("Choose a meal type and select your desired add on desserts...");
                    //Using Dictionary to store non veg food choices and it's respective price
                    Dictionary<string, string> foodst = new Dictionary<string, string>();
                    foodst.Add("Non-veg Soup", "200");
                    foodst.Add("Basic non veg breakfast meal", "500");
                    foodst.Add("Premium non veg breakfast meal", "950");
                    foodst.Add("Basic non veg platter", "800");
                    foodst.Add("Premium non veg platter", "1500");
                    foodst.Add("Basic non veg dinner meal", "550");
                    foodst.Add("Premium non veg dinner meal", "1100");
                    foodst.Add("Rasagulla(4pieces)", "150");
                    foodst.Add("Kova (50gms)", "100");
                    foodst.Add("Gulab Jaamun(4pieces)", "100");
                    foodst.Add("Ice Cream", "50");
                    foodst.Add("Fruit salad", "100");

                    int e, f;
                    g = 0;
                    //Asking planner to choose multiple desired veg food options
                    while (true)
                    {

                    nonvegfoodSection: e = 1;
                        foreach (KeyValuePair<string, string> item in foodst)
                        {
                            homePageObject.centerText($"Food type option {e} : {item.Key} Cost : {item.Value}");
                            e++;
                        }
                        homePageObject.centerText("Enter 99 key to exit");

                        Console.CursorLeft = Console.WindowWidth / 2;
                        try
                        {
                            food = Convert.ToInt32(Console.ReadLine());
                        }
                        catch (Exception excep)
                        {
                            homePageObject.centerText("\n Wrong format");
                            goto nonvegfoodSection;
                        }

                        if (food == 99)
                        {

                            break;
                        }
                        f = 1;
                        int temp = 0;
                        foreach (KeyValuePair<string, string> item in foodst)
                        {
                            if (food == f)
                            {
                                //If the planner has already selected the same option earlier
                                if (nvfoodchoices.Contains(Convert.ToString(item.Key)))
                                {
                                    homePageObject.centerText("You have already selected this option, please select another option");
                                    break;
                                }
                                //Storing the non veg food choice name an total price for all guests in array
                                nvfoodchoices[g] = Convert.ToString(item.Key);
                                temp = numOfGuests * (Convert.ToInt32((item.Value)));
                                nvfoodchoices[g + 1] = Convert.ToString(temp);
                                g += 2;
                                break;
                            }
                            f++;
                        }
                    }
                    break;
                default:
                    break;
            }
            //Asking planner if they want to include games
            homePageObject.centerText("Do you want to play games Y/N?");
            Console.CursorLeft = Console.WindowWidth / 2;
            string games = Console.ReadLine();

            if (games.ToLower() == "y")
            {
                homePageObject.centerText("Thanks for Conforming.... ");

            }
            else
            { }
            //Asking planner if they want to include music
            homePageObject.centerText("Do you want some music Y/N?");
            Console.CursorLeft = Console.WindowWidth / 2;
            string music = Console.ReadLine();
            if (music.ToLower() == "y")
            {
                homePageObject.centerText("Thanks for Conforming.... ");

            }
            else
            { }
            //Asking planner if they want to include return gifts
            homePageObject.centerText("Do you want to give return gifts for your guests Y/N?");
            Console.CursorLeft = Console.WindowWidth / 2;
            string returngifts = Console.ReadLine();
            if (returngifts.ToLower() == "y")
            {
                homePageObject.centerText("Thanks for Conforming.... ");

            }
            else
            { }


            int flag = 0;
            string filename = dir + "GuestCredentials" + extension + ".txt";
            while (flag == 0)
            {
                filename = dir + "GuestCredentials" + extension + ".txt";

                if (File.Exists(filename))
                {
                    extension++;
                }
                else
                {
                    Console.WriteLine(filename + "\n File doesn't Exists...");
                    flag = 1;

                }
            }

            //Storing guest username and password details to an event specific file
            using (StreamWriter wrt = File.CreateText(filename))
            {
                for (int i = 0; i < numOfGuests; i++)
                {
                    wrt.WriteLine(guestname[i]);
                    wrt.WriteLine(mobilenum[i]);
                }
            }

            homePageObject.centerText(filename + "Created...");



            //Storing all event details selected by planner(decor types,cake,food options,games,etc) into event specific file
            //Event details - Item name and total price for general items
            //Event details - Item name, total price and per person price for Individual specific items
            detailfilename = dir + "Details" + extension + ".txt";
            using (StreamWriter wrt = File.CreateText(detailfilename))
            {

                for (int i = 0; i < m; i++)
                {
                    wrt.WriteLine(decorchoices[i]);

                }


                if (cakeChoice == "y")
                {
                    wrt.WriteLine("cake");
                    wrt.WriteLine(cakeWeightInKG * 700);
                }

                if (music == "y")
                {
                    wrt.WriteLine("music");
                    wrt.WriteLine(1000);
                }

                //Adding seperator "****" to differentiate between general items and Individual specific items
                wrt.WriteLine("****");
                if (foodchoice == 1)
                {
                    for (int i = 0; i < c; i++)
                    {
                        if (i % 2 == 0)
                        {
                            wrt.WriteLine(vfoodchoices[i]);
                        }
                        else
                        {
                            wrt.WriteLine(vfoodchoices[i]);
                            wrt.WriteLine(Convert.ToInt32(vfoodchoices[i]) / numOfGuests);

                        }

                    }
                }

                if (foodchoice == 2)
                {
                    for (int i = 0; i < g; i++)
                    {
                        if (i % 2 == 0)
                        {
                            wrt.WriteLine(nvfoodchoices[i]);
                        }
                        else
                        {
                            wrt.WriteLine(nvfoodchoices[i]);
                            wrt.WriteLine(Convert.ToInt32(nvfoodchoices[i]) / numOfGuests);

                        }

                    }
                }

                if (games == "y")
                {
                    wrt.WriteLine("games");
                    wrt.WriteLine(300 * numOfGuests);
                    wrt.WriteLine(300);
                }

                if (returngifts == "y")
                {
                    wrt.WriteLine("returngifts");
                    wrt.WriteLine(150 * numOfGuests);
                    wrt.WriteLine(150);
                }
            }

            //Appending the current event to the planner specific file
            //This file will consist of extensions of all the events that the particular planner created
            string userFileName3 = dir + userNameForFile + ".txt";
            using (StreamWriter wrt = File.AppendText(userFileName3))
            {
                wrt.WriteLine(extension);
            }

            //Storing basic event details (items that do not cost money) to event specific file
            string basidDetailsFilename = dir + "BasicDetails" + extension + ".txt";
            using (StreamWriter wrt = File.AppendText(basidDetailsFilename))
            {
                wrt.WriteLine(enteredEventName);
                wrt.WriteLine(eventType);
                wrt.WriteLine(dt);
                wrt.WriteLine(numOfGuests);
                wrt.WriteLine("TRSHEV"+extension);
            }

            string allEventsFilename = dir + "AllEvents.txt";
            using (StreamWriter wrt = File.AppendText(allEventsFilename))
            {
                wrt.WriteLine(extension);
            }
        }
    }
}