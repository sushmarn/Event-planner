﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;

namespace PartyProject
{
    public class Guest
    {
        public static int eventId;
        string a, b;

        public void Guestlogin()
        {
            HomePage homePageObject = new HomePage();

        EventChoiceSection: homePageObject.centerText("Enter which event you are invited to");
            string dir = Directory.GetCurrentDirectory();
            string allEventsFilename = dir + "AllEvents.txt";
            string[] allEventsFileArray =File.ReadAllLines(allEventsFilename);
            int eventNumber = 1;
            for(int i2=0;i2< allEventsFileArray.Length;i2++)
            {
                string basicDetailsFilename = dir + "BasicDetails"+ allEventsFileArray [i2]+ ".txt";
                string[] basicDetailsFileArray = File.ReadAllLines(basicDetailsFilename);
                homePageObject.centerText($"{eventNumber}. Event {basicDetailsFileArray[0]}");
                homePageObject.centerText($"Event type is {basicDetailsFileArray[1]}, on {basicDetailsFileArray[2]} with {basicDetailsFileArray[3]} number of guests");
                homePageObject.centerText($"Event ID is {basicDetailsFileArray[4]}");
                eventNumber++;
            }
            homePageObject.centerText("Press 99 to go back to Homepage");


            int enteredEventChoice;
            Console.CursorLeft = Console.WindowWidth / 2;
            try
            {
                enteredEventChoice = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception e)
            {
                homePageObject.centerText("Wrong Format...");
                goto EventChoiceSection;

            }
            if(enteredEventChoice==99)
            {
                homePageObject.DisplayHomePage();
            }
            if (enteredEventChoice > allEventsFileArray.Length)
            {
                homePageObject.centerText("Wrong choice, please enter a valid choice");
                goto EventChoiceSection;
            }
            eventId = Convert.ToInt32(allEventsFileArray[enteredEventChoice - 1]);

            //Retreiving guest username and password from event specific file and storing in array

            string filename = dir + "GuestCredentials" + eventId + ".txt";
            string[] filearray = File.ReadAllLines(filename);
            int i = 0;
            //Storing guest username and password in Dictionary as key value pairs
            Dictionary<string, string> dict = new Dictionary<string, string>();

            foreach (var item in filearray)
            {

                if (i % 2 == 0)
                {
                    a = item;
                }

                else
                {
                    b = item;
                    dict.Add(a, b);
                }
                i++;
            }

            //Comment this later
            foreach (KeyValuePair<string, string> item in dict)
            {
                homePageObject.centerText("Key: " + " " + item.Key + " Value " + item.Value);
            }

            homePageObject.centerText("WELCOME TO TARUSH EVENT PLANNERS");
            string usn, pwd;
            homePageObject.centerText("Enter your username");
            Console.CursorLeft = (Console.WindowWidth / 2)-4;
            usn = Console.ReadLine();
            //Checking if entered username exists as a dictionary key
            if (!dict.ContainsKey(usn))
                homePageObject.centerText("Wrong username");
            else
            {
                homePageObject.centerText("Enter your password");
                Console.CursorLeft = (Console.WindowWidth / 2)-4;
                pwd = Console.ReadLine();
                //Validating the password (value) against the specific username key in dictionary
                if (dict[usn] != pwd)
                {
                    homePageObject.centerText("Wrong password");
                }
                else
                {
                    string basicDetailsFilename = dir + "BasicDetails" + eventId + ".txt";
                    string[] basicDetailsFileArray = File.ReadAllLines(basicDetailsFilename);
                    DateTime date = DateTime.Now;
                    TimeSpan ts = new TimeSpan(0, 0, 0);
                    date = date.Date + ts;
                    if (date<Convert.ToDateTime(basicDetailsFileArray[2]))
                    {
                        homePageObject.centerText($"Your account is not accessible to you now, please come back on {basicDetailsFileArray[2]}");
                        homePageObject.centerText("Press any key to go back");
                        Console.ReadKey();
                        goto EventChoiceSection;
                    }
                    if(date > Convert.ToDateTime(basicDetailsFileArray[2]))
                    {
                        homePageObject.centerText("Sorry, this event has ended");
                        homePageObject.centerText("Press any key to go back");
                        Console.ReadKey();
                        goto EventChoiceSection;
                    }
                    homePageObject.centerText("Your Login is Successful..");
                    homePageObject.centerText("Please wait a second, we are redirecting you to Guest Dashboard... Have a nice Party!!!");
                    Thread.Sleep(2000);
                    Console.Clear();

                    string GuestsAttendedFilename = dir + "GuestsAttended" + eventId + ".txt";
                    string[] GuestsAttendedFileArray = File.ReadAllLines(GuestsAttendedFilename);
                    int flag = 0;
                    //Check if this guest has already logged in earlier
                    foreach(var item in GuestsAttendedFileArray)
                    {
                        if(usn==item)
                        {
                            flag = 1;
                        }
                    }
                    //write username in file only if same username not present, to prevent duplicates
                    if(flag==0)
                    {
                        using (StreamWriter wrt = File.AppendText(GuestsAttendedFilename))
                        {
                            wrt.WriteLine(usn);
                        }
                    }
                    GuestDashboard gad = new GuestDashboard();
                    gad.Guestpage();
                }

            }


        }
    }
}