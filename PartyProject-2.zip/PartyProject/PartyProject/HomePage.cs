﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartyProject
{
    public class HomePage
    {
        Admin adminObject1 = new Admin();
        public void centerText(string text)
        {
            Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (text.Length / 2)) + "}", text));
        }
        public void centerTextWrite(string text)
        {
            Console.Write(String.Format("{0," + ((Console.WindowWidth / 2) + (text.Length / 2)) + "}", text));
        }
        public void Displayname()
        {
            Console.BackgroundColor = ConsoleColor.DarkRed;
            Console.Clear();
            //displaying the Company name
            var arr = new[]
            {
                  @"         $$$$$$$$   $$$$$   $$$$$$$  $$$ $$$ $$$$$$$ $$$  $$$       ",
                  @"         $$$$$$$$  $$$ $$$  $$$  $$  $$$ $$$ $$$$$$$ $$$  $$$       ",
                  @"           $$$$   $$$$ $$$$ $$$  $$  $$$ $$$ $$$$    $$$  $$$       ",
                  @"           $$$$   $$$$$$$$$ $$$$$$   $$$ $$$  $$$$   $$$$$$$$       ",
                  @"           $$$$   $$$$$$$$$ $$$ $$   $$$ $$$    $$$$ $$$  $$$       ",
                  @"           $$$$   $$$$ $$$$ $$$  $$  $$$ $$$ $$$$$$$ $$$  $$$       ",
                  @"           $$$$   $$$$ $$$$ $$$   $$ $$$$$$$ $$$$$$$ $$$  $$$       ",
                  @"                                                                    ",
                  @"                                                                    ",
                  @"                                                                    ",
                  @"   $$$$$$$ $$$           $$$ $$$$$$$ $$$$$$     $$$ $$$$$$$$ $$$$$$$",
                  @"   $$       $$$         $$$  $$      $$$$$$     $$$ $$$$$$$$ $$$$$$$",
                  @"   $$        $$$       $$$   $$      $$$ $$$    $$$   $$$$   $$$$   ",
                  @"   $$$$$$$    $$$     $$$    $$$$$$$ $$$  $$$   $$$   $$$$    $$$$  ",
                  @"   $$          $$$   $$$     $$      $$$   $$$  $$$   $$$$      $$$$",
                  @"   $$           $$$ $$$      $$      $$$    $$$ $$$   $$$$   $$$$$$$",
                  @"   $$$$$$$       $$$$$       $$$$$$$ $$$     $$$$$$   $$$$   $$$$$$$",

            };

            Console.WriteLine("\n\n");
            foreach (string line in arr)
                centerText(line);
            Console.ReadKey();
        }
        public void DisplayHomePage()
        {
            Console.BackgroundColor = ConsoleColor.DarkRed;
            Console.Clear();
            int homePageSelect;
            Console.Clear();
            //Console.WriteLine("\n \t Welcome to TARUSH EVENT PLANNERS!!!");
            Console.WriteLine();
            centerText("Welcome to TARUSH EVENT PLANNERS!!!");
            Console.WriteLine("\n");
            int flag = 0;
            while (flag == 0)
            {
            Main: centerText("Are you an Admin or a Guest?");
                centerText("1. Admin");
                centerText("2. Guest");
                centerText("3. Exit");
                Console.CursorLeft = Console.WindowWidth / 2;
                try
                {
                    homePageSelect = Convert.ToInt32(Console.ReadLine());

                }
                catch (Exception e)
                {
                    //Console.WriteLine("\n Wrong Format...");
                    centerText("Wrong Format...");
                    goto Main;

                }
                switch (homePageSelect)
                {
                    case 1:
                        //Console.WriteLine("\n Admin...");
                        centerText("Admin...");
                        flag = 1;
                        adminObject1.AdminSelect();
                        break;

                    case 2:
                        //Console.WriteLine("\n Guest user...");
                        centerText("Guest user...");
                        Guest guestObject = new Guest();
                        guestObject.Guestlogin();
                        flag = 1;
                        break;
                    case 3:
                        System.Environment.Exit(1);
                        break;
                    default:
                        //Console.WriteLine("\n Wrong choice, Enter again");
                        centerText("Wrong choice, Enter again");
                        break;
                }
            }

        }
    }
}