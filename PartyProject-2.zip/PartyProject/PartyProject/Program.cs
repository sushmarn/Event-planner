﻿using System;

namespace PartyProject
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            HomePage hm = new HomePage();
            hm.Displayname();
            hm.DisplayHomePage();
        }
    }
}
