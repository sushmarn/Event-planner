﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;

namespace PartyProject
{
    public class Admin
    {
        string a, b;

        static string dir = Directory.GetCurrentDirectory();
        string adminCredentialsFilename = dir + "AdminCredentials.txt";


        public void AdminSelect()
        {

            HomePage homePageObject = new HomePage();
            //Selecting Admin Signup or Login
            HomePage homePageObject2 = new HomePage();
            int adminSelectoption;
            homePageObject.centerText("Do you want to");
            homePageObject.centerText("1.Sign Up");
            homePageObject.centerText("2.Login");
            homePageObject.centerText("3.Go Back to Home Page");
            Console.CursorLeft = Console.WindowWidth / 2;
            adminSelectoption = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            switch (adminSelectoption)
            {
                case 1:
                    homePageObject.centerText("Admin Signup...");
                    AdminSignup();
                    break;

                case 2:
                    homePageObject.centerText("Admin Login...");
                    AdminLogin();
                    break;

                case 3:
                    Console.Clear();

                    homePageObject2.DisplayHomePage();
                    break;

                default:
                    break;

            }
        }


        public void AdminSignup()
        {

            HomePage homePageObject = new HomePage();
            string userNameEntered;
        Username: homePageObject.centerText("Enter your new user name: ");
            Console.CursorLeft = Console.WindowWidth / 2;
            try
            {
                userNameEntered = Console.ReadLine();

            }
            catch (Exception e)
            {
                homePageObject.centerText("Wrong Format...");
                goto Username;

            }
            if (File.Exists(adminCredentialsFilename))
            {
                string[] adminCredentialsFilearray = File.ReadAllLines(adminCredentialsFilename);
                for (int i = 0; i < adminCredentialsFilearray.Length; i++)
                {
                    if (adminCredentialsFilearray[i] == userNameEntered && i % 2 == 0)
                    {
                        homePageObject.centerText("Sorry, this username is already taken, please choose a different username");
                        goto Username;
                    }
                }
            }

        Password: homePageObject.centerText("Enter your new Password: ");
            string passwordEntered;
            Console.CursorLeft = Console.WindowWidth / 2;
            try
            {
                passwordEntered = Console.ReadLine();

            }
            catch (Exception e)
            {
                homePageObject.centerText("Wrong Format...");
                goto Password;

            }

            if (File.Exists(adminCredentialsFilename))
            {
                homePageObject.centerText("File Exists...");

            }
            else
                homePageObject.centerText(adminCredentialsFilename + "File doesn't Exists...");

            //Storing username and passowrd to a common file
            using (StreamWriter wrt = File.AppendText(adminCredentialsFilename))
            {
                wrt.WriteLine(userNameEntered);
                wrt.WriteLine(passwordEntered);
            }

            homePageObject.centerText("Your signup is Successful...");
            homePageObject.centerText("Your will be redirected to the Login page...");
            Thread.Sleep(2000);
            Console.Clear();
            AdminLogin();
        }


        public void AdminLogin()
        {

            HomePage homePageObject = new HomePage();
            if (!File.Exists(adminCredentialsFilename))
            {
                homePageObject.centerText("No existing users, please Sign up first");
                AdminSignup();
            }
            string[] adminCredentialsFilearray = File.ReadAllLines(adminCredentialsFilename);
            int i = 0;

            //Creating Dictionary to check valid username and password
            Dictionary<string, string> adminCredentialsDict = new Dictionary<string, string>();

            foreach (var item in adminCredentialsFilearray)
            {

                if (i % 2 == 0)
                {
                    a = item;
                }

                else
                {
                    b = item;
                    adminCredentialsDict.Add(a, b);
                }
                i++;
            }

            //Comment this later
            //foreach (KeyValuePair<string, string> item in adminCredentialsDict)
            //{
                //homePageObject.centerText("Key: " + " " + item.Key + " Value " + item.Value);
            //}

            string userNameEntered, passwordEntered;
            homePageObject.centerText("WELCOME TO TARUSH EVENT PLANNERS");

        //Verifying username is there or not in that created file
        usernameSection: homePageObject.centerText("Enter your username");
            Console.CursorLeft = Console.WindowWidth / 2;
            userNameEntered = Console.ReadLine();
            if (!adminCredentialsDict.ContainsKey(userNameEntered))
            {
                homePageObject.centerText("Wrong username");
                goto usernameSection;
            }

            else
            {
            //Verifying password is there or not against username
            passwordSection: homePageObject.centerText("Enter your password");
                Console.CursorLeft = Console.WindowWidth / 2;
                passwordEntered = Console.ReadLine();
                if (adminCredentialsDict[userNameEntered] != passwordEntered)
                {
                    homePageObject.centerText("Wrong password");
                    goto passwordSection;
                }
                else
                {
                    homePageObject.centerText("Your Login is Successful..");
                    Console.Clear();
                    AdminDashboard adminDashboardObject = new AdminDashboard(userNameEntered);
                    adminDashboardObject.AdminDashboardSelect();
                }

            }
        }
    }
}



