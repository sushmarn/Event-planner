﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PartyProject
{
    class Game
    {

        static int wrongGuess, lettersLeft;
        static char[] arr = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };

        static int player = 1;

        static int choice;
        static int flag = 0;
        public void games()
        {
            Random r = new Random();
            HomePage homePageObject = new HomePage();
            GuestDashboard gdb = new GuestDashboard();
        gameoption: homePageObject.centerText("Enter the game you want to play");
            homePageObject.centerText("1. Word Play");
            homePageObject.centerText("2. Tic-Tac-Toe");
            homePageObject.centerText("3.Main Menu ");
            homePageObject.centerText("4.Exit");
            int selectgame;
            Console.CursorLeft = Console.WindowWidth / 2;
            try
            {
                selectgame = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception e)
            {
                homePageObject.centerText("Wrong Format...");
                goto gameoption;

            }

            switch (selectgame)
            {
                case 1:
                    homePageObject.centerText("Welcome to Word Play");
                    games1();
                    break;

                case 2:
                    homePageObject.centerText("Welcome to Tic-Tac-Toe");
                    games2();
                    break;

                case 3:
                    gdb.Guestpage();
                    break;

                default:
                    break;
            }

        }
        public void games1()
        {
            HomePage homePageObject = new HomePage();
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.Clear();
            string wordToGuess = GetWordToGuess();

            char[] maskedWord = GetHiddenLetters(wordToGuess, '-');

            lettersLeft = wordToGuess.Length;
            char userGuess;

            wrongGuess = 5;

            while (wrongGuess > 0 && lettersLeft > 0)
            {
                DisplayCharacters(maskedWord);

                Console.WriteLine("Enter a letter?");
                Console.CursorLeft = Console.WindowWidth / 2;
                userGuess = char.Parse(Console.ReadLine());

                maskedWord = CheckGuess(userGuess, wordToGuess, maskedWord);
            }
            if (wrongGuess <= 0)
            {
                Console.WriteLine("Sorry Game Over!!! Try Again...");
            }
            else
            {
                Console.WriteLine("Well done! Thanks for playing.");
            }


            string GetWordToGuess()
            {
                Random number = new Random();
                int wordNumber = number.Next(0, 9);

                string[] words = { "bahubali", "chhichhore", "doom", "dabang", "master", "dilse", "kuch-kuch-hota-hai", "chennai express", "kalang", "sholay" };

                string selectWord = words[wordNumber];
                return selectWord;
            }

            char[] GetHiddenLetters(string word, char mask)
            {
                char[] hidden = new char[word.Length];

                for (int i = 0; i < word.Length; i++)
                {
                    hidden[i] = mask;
                }

                return hidden;
            }

            void DisplayCharacters(char[] characters)
            {
                foreach (char letter in characters)
                {
                    Console.Write(Convert.ToString(letter));
                }
                Console.WriteLine();
            }

            char[] CheckGuess(char letterToCheck, string word, char[] characters)
            {
                int flag = 0;
                if (wrongGuess > 0)
                {
                    for (int i = 0; i < word.Length; i++)
                    {
                        if (word[i] == letterToCheck)
                        {
                            characters[i] = word[i];
                            lettersLeft--;
                            flag = 1;
                        }
                    }
                }

                if (flag == 0)
                {
                    wrongGuess--;
                }

                return characters;
            }
        }

        public void games2()
        {
            HomePage homePageObject = new HomePage();
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.Clear();
            do

            {

                Console.Clear();

                homePageObject.centerText("Computer:X and Player:O");

                Console.WriteLine("\n");
                Board();

                if (player % 2 == 0)//checking the chance of the player  

                {

                playerChoice: homePageObject.centerText("It's your turn now, enter number of any unfilled box");
                    Console.CursorLeft = Console.WindowWidth / 2;
                    try
                    {
                        choice = int.Parse(Console.ReadLine());
                    }
                    catch (Exception e)
                    {
                        homePageObject.centerText("Wrong Format...");
                        goto playerChoice;
                    }


                }
                else

                {

                    homePageObject.centerText("Computer is playing");

                }

                Console.WriteLine("\n");


                Random r1 = new Random();
                int rand = r1.Next(1, 10);

                // checking that position where user want to run is marked (with X or O) or not  

                if ((arr[choice] != 'X' && arr[choice] != 'O') || (arr[rand] != 'X' && arr[rand] != 'O'))

                {

                    if (player % 2 == 0) //if chance is of player then mark O else mark X  

                    {

                        arr[choice] = 'O';

                        player++;

                    }

                    else

                    {

                        arr[rand] = 'X';

                        player++;

                    }

                }

                else //If there is any possition where user want to run and that is already marked then show message and load board again  

                {

                    homePageObject.centerText($"Sorry the row {choice} is already marked with {arr[choice]}");

                    Console.WriteLine("\n");

                    homePageObject.centerText("Please wait 2 second board is loading again.....");

                    Thread.Sleep(2000);

                }

                flag = CheckWin();// calling of check win  

            } while (flag != 1 && flag != -1);// This loop will be run until all cell of the grid is not marked with X and O or some player is not win  



            Console.Clear();// clearing the console  

            Board();// getting filled board again  



            if (flag == 1)// if flag value is 1 then some one has win or means who played marked last time which has win  

            {
                if (((player % 2) + 1) == 1)
                    homePageObject.centerText("Sorry, Computer has won");
                else
                {
                    homePageObject.centerText("Congratulations, you have won!!!!");
                }

            }

            else// if flag value is -1 the match will be draw and no one is winner  

            {

                homePageObject.centerText("Draw");

            }
            Console.CursorLeft = Console.WindowWidth / 2;


        }

        // Board method which creats board  

        private void Board()

        {
            HomePage homePageObject = new HomePage();

            homePageObject.centerText("     |     |      ");

            homePageObject.centerText($"{arr[1]}  |  {arr[2]}  |  {arr[3]}");

            homePageObject.centerText("   __|  _  | __  ");

            homePageObject.centerText("     |     |      ");

            homePageObject.centerText($"{arr[4]}  |  {arr[5]}  |  {arr[6]}");

            homePageObject.centerText("   __|  _  | __  ");

            homePageObject.centerText("     |     |      ");

            homePageObject.centerText($"{arr[7]}  |  {arr[8]}  |  {arr[9]}");

            homePageObject.centerText("     |     |      ");

        }



        //Checking that any player has won or not  

        private static int CheckWin()

        {

            #region Horzontal Winning Condtion

            //Winning Condition For First Row   

            if (arr[1] == arr[2] && arr[2] == arr[3])

            {

                return 1;

            }

            //Winning Condition For Second Row   

            else if (arr[4] == arr[5] && arr[5] == arr[6])

            {

                return 1;

            }

            //Winning Condition For Third Row   

            else if (arr[6] == arr[7] && arr[7] == arr[8])

            {

                return 1;

            }

            #endregion



            #region vertical Winning Condtion

            //Winning Condition For First Column       

            else if (arr[1] == arr[4] && arr[4] == arr[7])

            {

                return 1;

            }

            //Winning Condition For Second Column  

            else if (arr[2] == arr[5] && arr[5] == arr[8])

            {

                return 1;

            }

            //Winning Condition For Third Column  

            else if (arr[3] == arr[6] && arr[6] == arr[9])

            {

                return 1;

            }

            #endregion



            #region Diagonal Winning Condition

            else if (arr[1] == arr[5] && arr[5] == arr[9])

            {

                return 1;

            }

            else if (arr[3] == arr[5] && arr[5] == arr[7])

            {

                return 1;

            }

            #endregion



            #region Checking For Draw

            // If all the cells or values filled with X or O then player or computer has won the match  

            else if (arr[1] != '1' && arr[2] != '2' && arr[3] != '3' && arr[4] != '4' && arr[5] != '5' && arr[6] != '6' && arr[7] != '7' && arr[8] != '8' && arr[9] != '9')

            {

                return -1;

            }

            #endregion



            else

            {

                return 0;

            }

        }
    }
}
