﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO; 

namespace PartyProject
{
    public class GuestDashboard
    {
        public void Guestpage()
        {
            HomePage homePageObject = new HomePage();
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.Clear();
            HomePage hp = new HomePage();
            int ext = Guest.eventId;
            string userinput;
            string dir = Directory.GetCurrentDirectory();
            string userFileName2 = dir + "Details" + ext + ".txt";
            string[] filearray2 = File.ReadAllLines(userFileName2);
            int flag1 = 0, flag2 = 0, flag3 = 0;
            foreach (var item in filearray2)
            {
                if (item == "games")
                {
                    flag1 = 1;
                }
                if (item == "music")
                {
                    flag2 = 1;
                }
                if (item == "returngifts")
                {
                    flag3 = 1;
                }

            }
            string[] entertainmentCategories = { "Games", "Music/DJ", "Quotes", "Lucky Draw", "Return gift", "Go back", "Logout to Homepage" };
        Guest:
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.Clear();
        eventChoiceSection: homePageObject.centerText("Enter what you want to do");
            for (int i = 0; i < entertainmentCategories.Length; i++)
            {

                Console.WriteLine($"{i + 1}. {entertainmentCategories[i]}");
            }
            int guestChoice;
            Console.CursorLeft = Console.WindowWidth / 2;
            try
            {
                guestChoice = Convert.ToInt32(Console.ReadLine());

            }
            catch (Exception e)
            {
                homePageObject.centerText("Wrong Format...");
                goto Guest;

            }

            if (guestChoice > entertainmentCategories.Length || guestChoice < 1)
            {
                homePageObject.centerText("Wrong choice, please choose again");
                goto eventChoiceSection;
            }

            Console.Clear();
            switch (guestChoice)
            {
                case 1:
                    homePageObject.centerText("Welcome to Gaming Session...");
                    if (flag1 == 0)
                    {
                        homePageObject.centerText("You do not have access to Games");
                        homePageObject.centerText("Press e to go back");
                        Console.CursorLeft = Console.WindowWidth / 2;
                        userinput = Console.ReadLine();
                        if (userinput == "e")
                        {
                            goto Guest;

                        }
                    }
                    else
                    {
                        Game ga = new Game();
                        ga.games();
                        homePageObject.centerText("Press e to go back");
                        Console.CursorLeft = Console.WindowWidth / 2;
                        userinput = Console.ReadLine();
                        if (userinput == "e")
                        {
                            goto Guest;

                        }
                    }

                    break;
                case 2:

                    homePageObject.centerText("Welcome to Music...");
                    if (flag2 == 0)
                    {
                        homePageObject.centerText("You do not have access to Games");
                        homePageObject.centerText("Press  e to go back");
                        Console.CursorLeft = Console.WindowWidth / 2;
                        userinput = Console.ReadLine();
                        if (userinput == "e")
                        {
                            goto Guest;

                        }
                    }
                    else
                    {
                        Music();
                        homePageObject.centerText("Press e to go back");
                        Console.CursorLeft = Console.WindowWidth / 2;
                        userinput = Console.ReadLine();
                        if (userinput == "e")
                        {
                            goto Guest;

                        }
                    }

                    break;

                case 3:

                    Quotes();
                    homePageObject.centerText("Press e to go back");
                    Console.CursorLeft = Console.WindowWidth / 2;
                    userinput = Console.ReadLine();
                    if (userinput == "e")
                    {
                        goto Guest;

                    }
                    break;

                case 4:
                    LuckyDraw();
                    homePageObject.centerText("Press  e to go back");
                    Console.CursorLeft = Console.WindowWidth / 2;
                    userinput = Console.ReadLine();
                    if (userinput == "e")
                    {
                        goto Guest;

                    }
                    break;

                case 5:
                    homePageObject.centerText("Welcome to Return Gift Session...");
                    if (flag3 == 0)
                    {
                        homePageObject.centerText("You do not have access to Return Gift");
                        homePageObject.centerText("Press  e to go back");
                        Console.CursorLeft = Console.WindowWidth / 2;
                        userinput = Console.ReadLine();
                        if (userinput == "e")
                        {
                            goto Guest;

                        }
                    }
                    else
                    {
                        ReturnGift();
                        homePageObject.centerText("Press  e to go back");
                        Console.CursorLeft = Console.WindowWidth / 2;
                        userinput = Console.ReadLine();
                        if (userinput == "e")
                        {
                            goto Guest;

                        }
                    }

                    break;

                case 6:
                    Console.Clear();
                    Guestpage();
                    break;

                case 7:
                    Console.Clear();
                    hp.DisplayHomePage();
                    break;

                default:
                    break;
            }
        }

        public void ReturnGift()
        {
            HomePage homePageObject = new HomePage();
            homePageObject.centerText("We have a return gift for you!!!");
            homePageObject.centerText("Please press r to see your return gift");
            Console.CursorLeft = Console.WindowWidth / 2;
            string userip = Console.ReadLine();
            if (userip == "r")
            {
                Console.Clear();
                homePageObject.centerText("It's an Amazon Gift Voucher, Congratulations!!!");
                homePageObject.centerText("Your Voucher ID is AMZNGFT6486");
                homePageObject.centerText("You can use this at www.amazon.com");
            }
        }


        //Displays a random quote
        public void Quotes()
        {
            HomePage homePageObject = new HomePage();
            string[] quote = { "Practice makes a Man Perfect", "Kindness always comes back", "Success is a series of small wins", "You are what you settle for", "Old ways don't open new doors" };
            Random number = new Random();
            int wordNumber = number.Next(0, 4);
            string selectquote = quote[wordNumber];
            homePageObject.centerText(selectquote);
        }

        //Chooses a number at random and checks if it is equal to the lucky number
        public void LuckyDraw()
        {
            HomePage homePageObject = new HomePage();
            Random number = new Random();
            int guestNumber = number.Next(1, 6);
            int luckyNumber = 3;
            if (guestNumber == luckyNumber)
            {
                homePageObject.centerText("Congratulations!!!!");
                homePageObject.centerText("You have won the lucky draw");
                homePageObject.centerText("Lucky draw gift details will be shared later");
            }
            else
            {
                homePageObject.centerText("Sorry, Try again");
            }
        }

        //Happy birthday music
        public static void Music()
        {
            Thread.Sleep(2000);
            Console.Beep(264, 125);
            Thread.Sleep(250);
            Console.Beep(264, 125);
            Thread.Sleep(125);
            Console.Beep(297, 500);
            Thread.Sleep(125);
            Console.Beep(264, 500);
            Thread.Sleep(125);
            Console.Beep(352, 500);
            Thread.Sleep(125);
            Console.Beep(330, 1000);
            Thread.Sleep(250);
            Console.Beep(264, 125);
            Thread.Sleep(250);
            Console.Beep(264, 125);
            Thread.Sleep(125);
            Console.Beep(297, 500);
            Thread.Sleep(125);
            Console.Beep(264, 500);
            Thread.Sleep(125);
            Console.Beep(396, 500);
            Thread.Sleep(125);
            Console.Beep(352, 1000);
            Thread.Sleep(250);
            Console.Beep(264, 125);
            Thread.Sleep(250);
            Console.Beep(264, 125);
            Thread.Sleep(125);
            Console.Beep(2642, 500);
            Thread.Sleep(125);
            Console.Beep(440, 500);
            Thread.Sleep(125);
            Console.Beep(352, 250);
            Thread.Sleep(125);
            Console.Beep(352, 125);
            Thread.Sleep(125);
            Console.Beep(330, 500);
            Thread.Sleep(125);
            Console.Beep(297, 1000);
            Thread.Sleep(250);
            Console.Beep(466, 125);
            Thread.Sleep(250);
            Console.Beep(466, 125);
            Thread.Sleep(125);
            Console.Beep(440, 500);
            Thread.Sleep(125);
            Console.Beep(352, 500);
            Thread.Sleep(125);
            Console.Beep(396, 500);
            Thread.Sleep(125);
            Console.Beep(352, 1000);
        }
    }
}
