﻿using System;

namespace PartyProject
{
    class Program
    {
        static void Main(string[] args)
        {
            //calling the HomePage
            HomePage hm = new HomePage();     
            hm.Displayname();
            hm.DisplayHomePage();
         }
     }
}
