﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PartyProject
{
    class AdminDashboard
    {
        public void demo()
        {
            Event ev = new Event();
            ev.Accept();

        }
    }

    class Event
    {
        public static int extension;
        static int num;
        static int cakenum;
        static int i, m, c, g;
        static int decor, food;
        static string[] guestname = new string[100];
        static string[] mobilenum = new string[100];
        string dir = Directory.GetCurrentDirectory();
        string[] decorchoices = new string[10];
        string[] vfoodchoices = new string[50];
        string[] nvfoodchoices = new string[50];
        string detailfilename;
        Dictionary<string, string> decorst = new Dictionary<string, string>();


        public void Accept()
        {
            Admin adm = new Admin();
            HomePage hp = new HomePage();
            int adminchoice;
            Console.WriteLine("Enter your choice\n \t 1. Create new Event\n \t 2. Display Events \n \t 3. Edit existing Events \n \t 4. Main Page \n \t 5. Logout");
            adminchoice = Convert.ToInt32(Console.ReadLine());
            switch (adminchoice)
            {
                case 1:
                    CreateEvent();
                    Accept();
                    break;
                case 2:
                    DisplayEvents();
                    Accept();
                    break;
                case 3:
                    EditEvents();
                    Accept();
                    break;
                case 4:
                    Console.Clear();
                    adm.AdmSelect();
                    break;
                case 5:
                    Console.Clear();
                    hp.login();
                    break;
                default:
                    break;
            }
        }

        public void DisplayEvents()
        {
            Console.WriteLine("\n Do you want to display \n \t 1.All details \n \t 2.Total Billing");
            int display = Convert.ToInt32(Console.ReadLine());
            switch (display)
            {
                case 1:
                    break;
                case 2:
                    Console.Clear();
                    Console.WriteLine("\n \t ************ Total Bill ************");
                    GenerateBill();
                    break;
                default:
                    break;
            }


        }

        public void GenerateBill()
        {
            string dir = Directory.GetCurrentDirectory();
            string fname = dir + "Details1.txt";
            string[] filearray = File.ReadAllLines(fname);
            int total = 0;
            int z = 0;
            foreach (var item in filearray)
            {
                if (item == "****")
                {
                    continue;
                }
                if (z % 2 == 0)
                {
                    Console.Write($"{item} price : ");
                    z++;
                }
                else
                {
                    Console.WriteLine(item);
                    total = total + Convert.ToInt32(item);
                    z++;
                }


            }
            Console.WriteLine($"total amount is {total}");


        }
        public void EditEvents()
        {
            Console.WriteLine("Edit Events");
        }
        public void CreateEvent()
        {
            extension = 1;
            string[] eventname = { "Birthday", "Marriage", "Get-to-gether", "Corporate" };
            Console.WriteLine("Enter the Event you are planning for \n Birthday, \n Marriage, \n Get-together, \n Corporate: ");
            string events;
            events = Console.ReadLine().ToLower();

            if (events == "birthday" || events == "marriage" || events == "get-to-gether" || events == "corporate")
            {

                datemain:  Console.WriteLine("\n Enter which Date you want for Event: ");
                DateTime dt = new DateTime();
                DateTime date = DateTime.Now;
                
                try
                {

                    dt = Convert.ToDateTime(Console.ReadLine());
                }
                catch (Exception e)
                {
                    //Console.BackgroundColor = ConsoleColor.Red;
                    //Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("\n Wrong date format");
                    goto datemain;

                }

                if (!(dt >= date))
                {
                    Console.WriteLine($"current date is {date} and entered date is {dt} expression is {!(dt >= date)}");

                    Console.WriteLine("\n Cannot book date for Event");
                    goto datemain;
                }
                
               
                

                Console.WriteLine("\n Enter the number of Guest You are Inviting for Event: ");

                num = Convert.ToInt32(Console.ReadLine());

                for (i = 0; i < num; i++)
                {
                    Console.WriteLine($"Enter name of guest {i + 1}");
                    guestname[i] = Console.ReadLine();
                    Console.WriteLine($"{guestname[i]} enter your mobile number: ");
                    mobilenum[i] = Console.ReadLine();
                }

                Console.WriteLine("\n Do you want cake Y/N?");
                string cake = Console.ReadLine();
                if (cake.ToLower() == "y")
                {
                    Console.WriteLine("\n How much cake you want?");
                    cakenum = Convert.ToInt32(Console.ReadLine());

                }
    
                    Console.Clear();
                    Console.WriteLine("\n \t Choose Your Decor types...");

                    decorst.Add("Stage decoration", "5000");
                    decorst.Add("Table decoration", "3000");
                    decorst.Add("Balloon decoration", "2500");
                    decorst.Add("Backdrop decoration", "3500");
                    decorst.Add("Flower decoration", "8000");

                    int k, l;
                    m = 0;
                    while (true)
                    {

                        k = 1;
                        foreach (KeyValuePair<string, string> item in decorst)
                        {
                            Console.WriteLine($"\n Decor type{k} : {item.Key} Cost : {item.Value}");
                            k++;
                        }
                        Console.WriteLine("Enter 99 key to exit");
                        decor = Convert.ToInt32(Console.ReadLine());

                        if (decor == 99)
                        {

                            break;
                        }
                        l = 1;
                        foreach (KeyValuePair<string, string> item in decorst)
                        {
                            if (decor == l)
                            {
                                if (decorchoices.Contains(Convert.ToString(item.Key)))
                                {
                                    Console.WriteLine("You have already selected this option, please select another option");
                                    break;
                                }
                                decorchoices[m] = Convert.ToString(item.Key);
                                decorchoices[m + 1] = Convert.ToString(item.Value);
                                m += 2;
                                break;
                            }
                            l++;
                        }
                    }

                    Console.Clear();
                    Console.WriteLine("\n Enter your food Preference \n \t 1.Veg \n \t 2.Non-Veg");
                    int foodchoice = Convert.ToInt32(Console.ReadLine());
                    switch (foodchoice)
                    {
                        case 1:
                            Console.WriteLine("\n \t Choose a meal type and select your desired add on desserts...");
                            Dictionary<string, string> vfoodst = new Dictionary<string, string>();
                            vfoodst.Add("Veg Soup", "100");
                            vfoodst.Add("Basic veg breakfast meal", "350");
                            vfoodst.Add("Premium veg breakfast meal", "700");
                            vfoodst.Add("Basic veg platter", "550");
                            vfoodst.Add("Premium veg platter", "1100");
                            vfoodst.Add("Basic veg dinner meal", "400");
                            vfoodst.Add("Premium veg dinner meal", "800");
                            vfoodst.Add("Rasagulla(4pieces)", "150");
                            vfoodst.Add("Kova (50gms)", "100");
                            vfoodst.Add("Gulab Jaamun(4pieces)", "100");
                            vfoodst.Add("Ice Cream", "50");
                            vfoodst.Add("Vegtable/Fruit salad", "100");

                            int a, b;
                            c = 0;
                            while (true)
                            {

                                a = 1;
                                foreach (KeyValuePair<string, string> item in vfoodst)
                                {
                                    Console.WriteLine($"\n Veg Food type{a} : {item.Key} Cost : {item.Value}");
                                    a++;
                                }
                                Console.WriteLine("Enter 99 key to exit");
                                food = Convert.ToInt32(Console.ReadLine());

                                if (food == 99)
                                {

                                    break;
                                }
                                b = 1;
                                foreach (KeyValuePair<string, string> item in vfoodst)
                                {
                                    if (food == b)
                                    {
                                        if (vfoodchoices.Contains(Convert.ToString(item.Key)))
                                        {
                                            Console.WriteLine("You have already selected this option, please select another option");
                                            break;
                                        }
                                        vfoodchoices[c] = Convert.ToString(item.Key);
                                        vfoodchoices[c + 1] = Convert.ToString(Convert.ToInt32((item.Value)) * num);
                                        c += 2;
                                        break;
                                    }
                                    b++;
                                }
                            }
                            break;
                        case 2:
                            Console.WriteLine("\n \t Choose a meal type and select your desired add on desserts...");
                            Dictionary<string, string> foodst = new Dictionary<string, string>();
                            foodst.Add("Non-veg Soup", "200");
                            foodst.Add("Basic non veg breakfast meal", "500");
                            foodst.Add("Premium non veg breakfast meal", "950");
                            foodst.Add("Basic non veg platter", "800");
                            foodst.Add("Premium non veg platter", "1500");
                            foodst.Add("Basic non veg dinner meal", "550");
                            foodst.Add("Premium non veg dinner meal", "1100");
                            foodst.Add("Rasagulla(4pieces)", "150");
                            foodst.Add("Kova (50gms)", "100");
                            foodst.Add("Gulab Jaamun(4pieces)", "100");
                            foodst.Add("Ice Cream", "50");
                            foodst.Add("Fruit salad", "100");

                            int e, f;
                            g = 0;
                            while (true)
                            {

                                e = 1;
                                foreach (KeyValuePair<string, string> item in foodst)
                                {
                                    Console.WriteLine($"\n Food type option {e} : {item.Key} Cost : {item.Value}");
                                    e++;
                                }
                                Console.WriteLine("Enter 99 key to exit");
                                food = Convert.ToInt32(Console.ReadLine());

                                if (food == 99)
                                {

                                    break;
                                }
                                f = 1;
                                int temp = 0;
                                foreach (KeyValuePair<string, string> item in foodst)
                                {
                                    if (food == f)
                                    {
                                        if (nvfoodchoices.Contains(Convert.ToString(item.Key)))
                                        {
                                            Console.WriteLine("You have already selected this option, please select another option");
                                            break;
                                        }
                                        nvfoodchoices[g] = Convert.ToString(item.Key);
                                        temp = num * (Convert.ToInt32((item.Value)));
                                        nvfoodchoices[g + 1] = Convert.ToString(temp);
                                        g += 2;
                                        break;
                                    }
                                    f++;
                                }
                            }
                            break;
                        default:
                            break;
                    }

                }
                else
                    Console.WriteLine("\n Sorry Wrong Event..");

                int flag = 0;
                string filename = dir + "GuestCredentials" + extension + ".txt";
                while (flag == 0)
                {
                    filename = dir + "GuestCredentials" + extension + ".txt";

                    if (File.Exists(filename))
                    {
                        extension++;
                    }
                    else
                    {
                        Console.WriteLine(filename + "\n File doesn't Exists...");
                        flag = 1;

                    }
                }

                using (StreamWriter wrt = File.CreateText(filename))
                {
                    for (int i = 0; i < num; i++)
                    {
                        wrt.WriteLine(guestname[i]);
                        wrt.WriteLine(mobilenum[i]);
                    }
                }

                Console.WriteLine(filename + "Created...");



                detailfilename = dir + "Details" + extension + ".txt";
                using (StreamWriter wrt = File.CreateText(detailfilename))
                {
                    for (int i = 0; i < m; i++)
                    {
                        wrt.WriteLine(decorchoices[i]);

                    }
                    wrt.WriteLine("****");
                    for (int i = 0; i < c; i++)
                    {

                        wrt.WriteLine(vfoodchoices[i]);

                    }
                    wrt.WriteLine("****");
                    for (int i = 0; i < g; i++)
                    {

                        wrt.WriteLine(nvfoodchoices[i]);

                    }
                    wrt.WriteLine("cake");
                    wrt.WriteLine(cakenum*700);

                }


            }


        }


    }


