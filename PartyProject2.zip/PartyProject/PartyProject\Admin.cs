﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PartyProject
{


    class Admin
    {
        int choice =HomePage.select;
        int option;
        string a, b;

        public void AdmSelect()
        { 
            Admin ad = new Admin();
            Console.WriteLine("Do you want to \n \t 1.Sign Up \n \t 2.Login \n \t 3.Exit");
            option = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            switch (option)
            {
                case 1:
                    Console.WriteLine("\n Admin Signup...");
                    ad.AdminSignup();
                    break;

                case 2:
                    Console.WriteLine("\n Admin Login...");
                    ad.Adminlogin();
                    break;
                default:
                    break;

            }
        }
        public void AdminSignup()
        {
            Console.WriteLine("Enter your name: ");
            string uname = Console.ReadLine();
            Console.WriteLine("Enter your Password: ");
            string pword = Console.ReadLine();

            string dir = Directory.GetCurrentDirectory();
            string filename = dir + "AdminCredentials.txt";

            if (File.Exists(filename))
            {
                Console.WriteLine("\n File Exists...");
               
            }
            else
                Console.WriteLine(filename + "\n File doesn't Exists...");

            using (StreamWriter wrt = File.AppendText(filename))
            {
                wrt.WriteLine(uname);
                wrt.WriteLine(pword);
            }
        }
        public void Adminlogin()
        {
            if (choice == 1)
            {
                string dir = Directory.GetCurrentDirectory();
                string filename = dir + "AdminCredentials.txt";
                string[] filearray = File.ReadAllLines(filename);
                int i = 0;
                

                Dictionary<string, string> dict = new Dictionary<string, string>();

                foreach (var item in filearray)
                {

                    if (i % 2 == 0)
                    {
                        a = item;
                    }

                    else
                    {
                        b = item;
                        dict.Add(a, b);
                    }
                    i++;
                }

                foreach (KeyValuePair<string, string> item in dict)
                {
                    Console.WriteLine("Key: " + " " + item.Key + " Value " + item.Value);
                }

                string usn, pwd;
                Console.WriteLine("WELCOME TO XYZ EVENT PLANNERS");
                Console.WriteLine("Enter your username");
                usn = Console.ReadLine();
                if (!dict.ContainsKey(usn))
                    Console.WriteLine("Wrong username");
                else
                {
                    Console.WriteLine("Enter your password");
                    pwd = Console.ReadLine();
                    if (dict[usn] != pwd)
                    {
                        Console.WriteLine("Wrong password");
                    }
                    else
                    {
                        Console.WriteLine("\n Your Login is Successfully..");
                        AdminDashboard amd = new AdminDashboard();
                        amd.demo();
                    }
                    
                }

            }
        }
        }
    }
