﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PartyProject
{
    class AdminDashboard
    {
        public void demo()
        {
            Event ev = new Event();
            ev.Accept();
 
        }
    }

     class Event
    {
        public static int extension ;
        static int num;
        static int i;
        static string[] guestname=new string[100];
         static string[] mobilenum = new string[100];

        public void Accept()
        {
            Admin adm = new Admin();
            int adminchoice;
            Console.WriteLine("Enter your choice\n1. Create new Event\n2.Display Events\n3. Edit existing Events\n4. Logout");
            adminchoice = Convert.ToInt32(Console.ReadLine());
            switch(adminchoice)
            {
                case 1:
                    CreateEvent();
                    Accept();
                    break;
                case 2:
                    DisplayEvents();
                    Accept();
                    break;
                case 3:
                    EditEvents();
                    Accept();
                    break;
                case 4:
                    Console.Clear();
                    adm.AdmSelect();
                    break;
                default:
                    break;
            }
        }

        public void DisplayEvents()
        {
            Console.WriteLine("Display Events");
        }
        public void EditEvents()
        {
            Console.WriteLine("Edit Events");
        }
        public void CreateEvent()
        {
            extension = 1;
            string[] eventname = { "Birthday", "Marriage", "Get-to-gether", "Corporate" };
            Console.WriteLine("Enter the Event you are planning for \n Birthday, \n Marriage, \n Get-together, \n Corporate: ");
            string events;
            events = Console.ReadLine().ToLower();
 
            if (events == "birthday" || events == "marriage" || events == "get-to-gether" || events == "corporate")
            {
                Console.WriteLine("\n Enter which Date you want for Event: ");
                DateTime dt = new DateTime();
                dt = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("\n Enter the number of Guest You are Inviting for Event: ");
                
                num = Convert.ToInt32(Console.ReadLine());
                
                for( i=0;i<num;i++)
                {
                    Console.WriteLine($"Enter name of guest {i+1}");
                    guestname[i] = Console.ReadLine();
                   Console.WriteLine($"{guestname[i]} enter your mobile number: ");
                    mobilenum[i] = Console.ReadLine();
                }
               
                    Console.WriteLine("Enter Your Decor types \n \t 1.");
                    int decor = Convert.ToInt32(Console.ReadLine());
                    switch (decor)
                    {
                        case 1:
                            Console.WriteLine("");
                            break;
                    }
            }
            else
                Console.WriteLine("\n Sorry Wrong Event..");
           
            int flag = 0;
            string dir = Directory.GetCurrentDirectory();
            string filename= dir + "GuestCredentials" + extension + ".txt";
            while (flag==0)
            {
                 filename = dir + "GuestCredentials" + extension + ".txt";

                Console.WriteLine($"extension is {extension}");

                if (File.Exists(filename))
                {
                    Console.WriteLine("\n File Exists...");
                    extension++;
                }
                else
                {
                    Console.WriteLine(filename + "\n File doesn't Exists...");
                    flag = 1;

                }
            }
            
            using (StreamWriter wrt = File.CreateText(filename))
            {
                for(int i=0;i<num;i++)
                {
                    wrt.WriteLine(guestname[i]);
                    wrt.WriteLine(mobilenum[i]);
                }
             }

            Console.WriteLine(filename + "Created...");

        }

       
    }

   
}

