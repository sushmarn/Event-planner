﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PartyProject
{
    class Guest
    {
        int choice = HomePage.select;
       
        string a, b;

        public void Guestlogin()
            {
                if (choice == 2)
               {
                int ex = 1;
                string dir = Directory.GetCurrentDirectory();
                string filename = dir + "GuestCredentials"+ex+".txt";
                string[] filearray = File.ReadAllLines(filename);
                int i = 0;

                Dictionary<string, string> dict = new Dictionary<string, string>();
                
                foreach (var item in filearray)
                {

                    if (i % 2 == 0)
                    {
                        a = item;
                    }
                        
                    else
                    {
                        b = item;
                        dict.Add(a, b);
                    }
                    i++;
                }

                foreach (KeyValuePair<string, string> item in dict)
                {
                    Console.WriteLine("Key: " + " " + item.Key + " Value " + item.Value);
                }
                string usn, pwd;
                    Console.WriteLine("WELCOME TO XYZ EVENT PLANNERS");
                    Console.WriteLine("Enter your username");
                    usn = Console.ReadLine();
                    if (!dict.ContainsKey(usn))
                        Console.WriteLine("Wrong username");
                    else
                    {
                        Console.WriteLine("Enter your password");
                        pwd = Console.ReadLine();
                        if (dict[usn]!=pwd )
                        {
                            Console.WriteLine("Wrong password");
                        }
                        else
                        {
                            Console.WriteLine("\n Your Login is Successfully..");
                            GuestDashboard gad = new GuestDashboard();
                            gad.Guestpage();
                    }
                        
                    }

                }
            }
        }
}
