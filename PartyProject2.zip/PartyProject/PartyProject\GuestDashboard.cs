﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartyProject
{
    class GuestDashboard
    {
        public void Guestpage()
        {
            Console.WriteLine("Hey Guest enter your option for event \n \t 1.Games \n \t 2.Music/DJ \n \t 3.Quote \n \t 4.Lucky draw \n \t 5.Return gift \n \t 6.Exit");
            int Guestoption = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            switch (Guestoption)
            {
                case 1:
                    Console.WriteLine("\n \t Welcome to Gaming Session...");
                    Game ga = new Game();
                    ga.games();
                    break;
            }
        }
        
        
    }
}
