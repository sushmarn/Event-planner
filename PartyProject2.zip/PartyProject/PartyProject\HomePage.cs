﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartyProject
{
    class HomePage
    {
        public static int select;
        public void login()
        {
            Console.WriteLine("Welcome to XYZ EVENT PLANNERS!!!");
            Console.WriteLine("May I know Who You are Admin or Guest \n \t 1.Admin \n \t 2.Guest \n \t 3.Exit");
            select = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            switch (select)
            {
                case 1:
                    Console.WriteLine("\n Admin...");
                    Admin ad = new Admin();
                    ad.AdmSelect();
                    break;

                case 2:
                    Console.WriteLine("\n Guest user...");
                    Guest gs = new Guest();
                    gs.Guestlogin();
                    break;
                default:
                    break;

            }
        }
    }
}
