﻿using System;

namespace PartyProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            HomePage hm = new HomePage();
            hm.login();
         }
     }
}
